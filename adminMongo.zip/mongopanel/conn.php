<?php
$conn = mysqli_connect('localhost', 'root', '', 'job');
?>