<?php
$client= new MongoDB\Client("mongodb://user:user123@3.6.34.87:27017/test");
?>